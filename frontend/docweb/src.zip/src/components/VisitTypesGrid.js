import TextField from "./TextField";

export default function VisitTypesGrid({visitTypes, onClick}) {
    return (
        <div className="grid grid-cols-3 gap-4">
            {visitTypes.map( visitType =>
                <TextField key={visitType} text={visitType} onClick={() => onClick(visitType)}/>
            ) }
        </div>
    );
};