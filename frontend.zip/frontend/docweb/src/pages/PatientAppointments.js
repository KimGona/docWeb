import React from "react";
import PageContainer from "../components/PageContainer";

export default function PatientAppointments() {
    return (
        <PageContainer title="Patient appointments">
        </PageContainer>
      );
}